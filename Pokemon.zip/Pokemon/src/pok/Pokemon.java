package pok;

public class Pokemon {
	private String nome;
	private int HP;
	private int[] dano = {10,20,30,40};
	private int prioridade = 0;
	
	public Pokemon(String n, int h){
		setNome(n);
		setHP(h);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getHP() {
		return HP;
	}

	public void setHP(int hP) {
		HP = hP;
	}

	public int getDano() {
		int d = dano[prioridade];
		prioridade++;
		if(prioridade>3){
			prioridade = 0;
		}
		return d;
	}
	
}

package pok;

public class BattleControls extends Controller {
	private Pokemon pikachu = new Pokemon("Pikachu",60);
	private Pokemon charmander = new Pokemon("Charmander",90);
	
	private Pokemon[] poks1 = {pikachu,charmander};
	private Pokemon[] poks2 = {charmander,pikachu};
	
	private Treinador t1 = new Treinador(poks1);
	private Treinador t2 = new Treinador(poks2);
	
	private int winner = 0;
		
	public class Atacar1 extends Event{
		private int d,h;
		public Atacar1(long evtTime){
			super(evtTime);
		}
		
		public void action() {
			d = t1.getPokemonAtivo().getDano();
			h = t2.getPokemonAtivo().getHP();
			t2.getPokemonAtivo().setHP(h-d);
		}

		public String description() {
			return t1.getPokemonAtivo().getNome() + " atacou "
					+ t2.getPokemonAtivo().getNome() + " em "
					+ d + " de dano !";
		}
	}
	
	public class Trocar1 extends Event{
		private String n1,n2;
		public Trocar1(long evtTime){
			super(evtTime);
		}
		
		public void action() {
			n1 = t1.getPokemonAtivo().getNome();
			t1.trocaPokemon();
			n2 = t1.getPokemonAtivo().getNome();
		}

		public String description() {
			return "Treinador 1 trocou o Pokemon " 
					+ n1 + " pelo Pokemon " + n2;
		}
	}
	
	public class Curar1 extends Event{
		private int cura = 30;
		public Curar1(long evtTime){
			super(evtTime);
		}
		
		public void action() {
			int h = t1.getPokemonAtivo().getHP();
			t1.getPokemonAtivo().setHP(h+cura);
		}

		public String description() {
			return "Treinador 1 curou seu pokemon " 
					+ t1.getPokemonAtivo().getNome() + " em " + cura
					+ "HP .";
		}
	}
	
	public class Fugir1 extends Event{
		public Fugir1(long evtTime){
			super(evtTime);
		}
		
		public void action() {
			winner = 2;
		}

		public String description() {
			return "Treinador 1 fugiu da batalha !";
		}
	}
	
	
	public static void main(String[] args) {
		BattleControls gc =	new BattleControls();
		long tm = System.currentTimeMillis();
		gc.addEvent(gc.new Atacar1(tm));
		gc.addEvent(gc.new Trocar1(tm+1000));
		gc.addEvent(gc.new Atacar1(tm+2000));
		gc.addEvent(gc.new Trocar1(tm+3000));
		gc.addEvent(gc.new Curar1(tm+4000));
		gc.run();
	}
} 

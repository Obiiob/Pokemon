package pok;

public class Treinador {
	private Pokemon[] pokemons = new Pokemon[6];
	private int pokemonAtivo = 0;
	private int nPoks;
	
	public Treinador(Pokemon[] poks){		
		nPoks = poks.length;
		for(int i=0;i<nPoks;i++){
			pokemons[i] = poks[i];
		}
	}
	
	public Pokemon getPokemonAtivo(){
		return pokemons[pokemonAtivo];
	}
	
	public void trocaPokemon() {
		pokemonAtivo = (pokemonAtivo + 1 ) % nPoks;
	}
	
	public class UsarItem extends Event{
		int curaItem = 30;
		
		public UsarItem(long evtTime){
			super(evtTime);
		}
		
		public void action() {
			int hP = pokemons[pokemonAtivo].getHP();
			pokemons[pokemonAtivo].setHP(hP + curaItem);
			
		}

		public String description() {
			return pokemons[pokemonAtivo].getNome() + " foi curado em "
					+ curaItem;
		}
	}
	public class Fugir extends Event{
		public Fugir(long evtTime){
			super(evtTime);
		}
		
		public void action() {
			// TODO Auto-generated method stub
			
		}

		public String description() {
			return null;
		}
	}
}